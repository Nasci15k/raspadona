# Raspadinha - Backend (PHP + MySQL)

Este é o backend da aplicação de raspadinhas, desenvolvido em PHP com banco de dados MySQL.

## Estrutura do Projeto

```
backend/
├── admin/                 # Painel administrativo
├── afiliados/            # Sistema de afiliados
├── api/                  # Endpoints da API
├── apostas/              # Lógica de apostas
├── bingo/                # Módulo de bingo
├── callback/             # Callbacks de pagamento
├── cartelas/             # Gerenciamento de cartelas
├── classes/              # Classes PHP
├── components/           # Componentes reutilizáveis
├── inc/                  # Includes
├── includes/             # Includes adicionais
├── login/                # Sistema de login
├── logout/               # Sistema de logout
├── page/                 # Páginas
├── perfil/               # Perfil do usuário
├── politica/             # Políticas
├── raspadinhas/          # Lógica das raspadinhas
├── transacoes/           # Gerenciamento de transações
├── vendor/               # Dependências Composer
├── conexao.php           # Configuração de conexão com BD
├── index.php             # Arquivo principal
├── database.sql          # Script SQL do banco de dados
├── .env.example          # Exemplo de variáveis de ambiente
├── Procfile              # Configuração para Render
└── composer.json         # Dependências do projeto
```

## Configuração de Variáveis de Ambiente

Antes de fazer o deploy, configure as seguintes variáveis de ambiente no Render:

1. `DB_HOST` - Host do banco de dados MySQL
2. `DB_PORT` - Porta do banco de dados (padrão: 3306)
3. `DB_NAME` - Nome do banco de dados
4. `DB_USER` - Usuário do banco de dados
5. `DB_PASSWORD` - Senha do banco de dados
6. `SITE_NAME` - Nome do site
7. `SITE_LOGO` - URL do logo do site
8. `DEPOSITO_MIN` - Depósito mínimo
9. `SAQUE_MIN` - Saque mínimo
10. `CPA_PADRAO` - CPA padrão
11. `REVSHARE_PADRAO` - Revshare padrão
12. `APP_ENV` - Ambiente (production/development)
13. `APP_DEBUG` - Debug ativo (true/false)

## Deploy no Render

### Passo 1: Criar um Repositório Git

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/seu_usuario/raspadinha-backend.git
git push -u origin main
```

### Passo 2: Conectar ao Render

1. Acesse https://render.com
2. Clique em "New +" e selecione "Web Service"
3. Conecte seu repositório GitHub
4. Selecione o repositório `raspadinha-backend`
5. Configure as seguintes informações:
   - **Name**: raspadinha-backend
   - **Environment**: PHP
   - **Build Command**: `composer install`
   - **Start Command**: `php -S 0.0.0.0:$PORT`
   - **Plan**: Free (ou pago, conforme necessário)

### Passo 3: Adicionar Variáveis de Ambiente

No painel do Render, vá para "Environment" e adicione todas as variáveis de ambiente listadas acima.

### Passo 4: Configurar Banco de Dados MySQL

No Render, você pode usar um serviço MySQL externo (como Planetscale, AWS RDS, etc.) ou criar um banco de dados MySQL no próprio Render.

**Opção 1: Usar um Banco de Dados Externo**

1. Crie um banco de dados MySQL em um provedor externo (ex: Planetscale, AWS RDS)
2. Importe o arquivo `database.sql` para o novo banco de dados
3. Configure as variáveis de ambiente com as credenciais do banco de dados externo

**Opção 2: Usar MySQL no Render**

1. No Render, clique em "New +" e selecione "MySQL"
2. Configure o banco de dados com o nome `raspadinha_db`
3. Importe o arquivo `database.sql` para o novo banco de dados
4. Configure as variáveis de ambiente com as credenciais do banco de dados

### Passo 5: Deploy

Após configurar tudo, o Render fará o deploy automaticamente quando você fizer push para o repositório.

## Instalação Local

Para instalar e executar localmente:

```bash
# Instalar dependências
composer install

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com suas credenciais locais

# Iniciar servidor PHP
php -S localhost:8000

# Acessar a aplicação
# http://localhost:8000
```

## Importar Banco de Dados

Para importar o banco de dados MySQL:

```bash
mysql -h localhost -u seu_usuario -p seu_banco < database.sql
```

## Suporte

Para mais informações sobre o Render, visite: https://render.com/docs
