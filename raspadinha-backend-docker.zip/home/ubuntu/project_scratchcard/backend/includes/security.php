<div id="security">
    <script>
        console.log("Desenvolvido por Yarkan +5584999591257")
        // NÃO APAGUE OS CRÉDITOS!
    </script>
</div>

<style>
    #security{
        display: none !important;
    }
</style>