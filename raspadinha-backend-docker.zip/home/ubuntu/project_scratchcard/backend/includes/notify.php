<?php 

echo '<style>
#NotiflixNotifyWrap {
    width: 240px !important;
    position: fixed !important; 
    top: 78px !important; 
    right: 10px !important;
    z-index: 4001 !important;
}
</style>';

?>